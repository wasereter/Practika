package com.example.praktika2;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polygon;
import org.osmdroid.views.overlay.Polyline;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private MapView mapView;
    private Button btnLoadGeoJson;
    private Button btnClearMap;
    private ProgressBar progressBar;
    private List<org.osmdroid.views.overlay.Overlay> geoJsonOverlays = new ArrayList<>();
    private Gson gson = new Gson();
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    private static final int REQUEST_PERMISSIONS_CODE = 1;
    private static final int REQUEST_MANAGE_STORAGE = 2;
    private static final int REQUEST_CODE_PICK_FILE = 1001;
    private static final int REQUEST_CODE_OPEN_DOCUMENT = 1002;
    private static final int MAX_FILE_SIZE_MB = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Configuration.getInstance().setUserAgentValue(getPackageName());
        Configuration.getInstance().load(this, getPreferences(MODE_PRIVATE));

        initViews();
        setupMap();
        checkPermissions();

        //обработка intent (если приложение открыто через файл)
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    // Метод handleIntent для обработки открытия файла через приложение
    private void handleIntent(Intent intent) {
        if (intent != null && intent.getAction() != null &&
                intent.getAction().equals(Intent.ACTION_VIEW)) {
            Uri uri = intent.getData();
            if (uri != null) {
                loadGeoJsonFromUri(uri);
            }
        }
    }

    private void initViews() {
        mapView = findViewById(R.id.mapView);
        btnLoadGeoJson = findViewById(R.id.btnLoadGeoJson);
        btnClearMap = findViewById(R.id.btnClearMap);
        progressBar = findViewById(R.id.progressBar);

        btnLoadGeoJson.setOnClickListener(v -> showFileSelector());
        btnClearMap.setOnClickListener(v -> clearGeoJsonOverlays());
    }

    private void setupMap() {
        mapView.setTileSource(TileSourceFactory.MAPNIK);
        mapView.setMultiTouchControls(true);
        mapView.getController().setZoom(10.0);
        mapView.getController().setCenter(new GeoPoint(59.985656, 42.750187));
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                requestManageStoragePermission();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        REQUEST_PERMISSIONS_CODE);
            }
        }
    }

    private void requestManageStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            startActivityForResult(intent, REQUEST_MANAGE_STORAGE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_MANAGE_STORAGE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    Toast.makeText(this, "Доступ к хранилищу разрешен", Toast.LENGTH_SHORT).show();
                }
            }
        }

        if ((requestCode == REQUEST_CODE_PICK_FILE || requestCode == REQUEST_CODE_OPEN_DOCUMENT)
                && resultCode == RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                if (uri != null) {
                    loadGeoJsonFromUri(uri);
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS_CODE) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Для загрузки файлов необходимо разрешение",
                            Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    private void showFileSelector() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Загрузить GeoJSON файл");

        //список опций
        CharSequence[] options = {
                "📂 Открыть документ",
                "📍 Открыть пример"
        };

        builder.setItems(options, (dialog, which) -> {
            switch (which) {
                case 0:
                    useOpenDocumentPicker();
                    break;
                case 1:
                    loadExampleGeoJson();
                    break;
            }
        });

        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void useOpenDocumentPicker() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_CODE_OPEN_DOCUMENT);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть документ", Toast.LENGTH_LONG).show();
        }
    }

    private void loadExampleGeoJson() {
        String exampleGeoJson = "{\n" +
                "  \"type\": \"FeatureCollection\",\n" +
                "  \"features\": [\n" +
                "    {\n" +
                "      \"type\": \"Feature\",\n" +
                "      \"geometry\": {\n" +
                "        \"type\": \"Point\",\n" +
                "        \"coordinates\": [42.750187, 59.985656]\n" +
                "      },\n" +
                "      \"properties\": {\n" +
                "        \"name\": \"Дом культуры Варницкий\"\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"type\": \"Feature\",\n" +
                "      \"geometry\": {\n" +
                "        \"type\": \"Point\",\n" +
                "        \"coordinates\": [35.317059, 58.884974]\n" +
                "      },\n" +
                "      \"properties\": {\n" +
                "        \"name\": \"Лукинский дом культуры\"\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        parseGeoJsonWithGson(exampleGeoJson);
        Toast.makeText(this, "Загружен пример с 2 объектами", Toast.LENGTH_SHORT).show();
    }

    private void loadGeoJsonFromUri(Uri uri) {
        showProgress(true);
        executorService.execute(() -> {
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                String geoJsonString = readStreamToString(inputStream);

                runOnUiThread(() -> {
                    parseGeoJsonWithGson(geoJsonString);
                    showProgress(false);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Ошибка загрузки: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                    showProgress(false);
                });
            }
        });
    }

    // МЕТОД: Чтение больших файлов по частям
    private String readLargeFile(File file) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        char[] buffer = new char[8192];
        int read;
        while ((read = reader.read(buffer)) > 0) {
            stringBuilder.append(buffer, 0, read);
        }
        reader.close();
        return stringBuilder.toString();
    }

    // Улучшенный парсинг для больших файлов
    private void parseGeoJsonWithGson(String geoJsonString) {
        clearGeoJsonOverlays();

        if (geoJsonString == null || geoJsonString.isEmpty()) {
            Toast.makeText(this, "Файл пустой", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            // Проверяем размер файла в памяти
            if (geoJsonString.length() > 5 * 1024 * 1024) { // 5 MB
                Toast.makeText(this, "Файл очень большой, обрабатываем по частям...",
                        Toast.LENGTH_SHORT).show();
                parseLargeGeoJson(geoJsonString);
            } else {
                parseRegularGeoJson(geoJsonString);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка парсинга: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    // Парсинг обычных файлов
    private void parseRegularGeoJson(String geoJsonString) {
        JsonObject geoJson = gson.fromJson(geoJsonString, JsonObject.class);
        String type = geoJson.get("type").getAsString();

        if ("FeatureCollection".equals(type)) {
            JsonArray features = geoJson.getAsJsonArray("features");
            int featureCount = 0;

            for (JsonElement featureElement : features) {
                try {
                    parseFeatureWithGson(featureElement.getAsJsonObject());
                    featureCount++;

                    // Обновляем прогресс каждые 10 объектов
                    if (featureCount % 10 == 0) {
                        final int currentCount = featureCount;
                        runOnUiThread(() -> {
                            Toast.makeText(this,
                                    "Обработано " + currentCount + " объектов",
                                    Toast.LENGTH_SHORT).show();
                        });
                    }
                } catch (Exception e) {
                    Log.e("GeoJSON", "Ошибка обработки объекта", e);
                }
            }

            Toast.makeText(this, "Загружено " + featureCount + " объектов",
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Неверный тип GeoJSON", Toast.LENGTH_LONG).show();
        }

        mapView.invalidate();
    }

    // Парсинг очень больших файлов
    private void parseLargeGeoJson(String geoJsonString) {
        try {
            JsonReader reader = new JsonReader(new StringReader(geoJsonString));
            reader.beginObject();

            int featureCount = 0;

            while (reader.hasNext()) {
                String name = reader.nextName();
                if ("type".equals(name)) {
                    String type = reader.nextString();
                    if (!"FeatureCollection".equals(type)) {
                        Toast.makeText(this, "Неверный тип GeoJSON", Toast.LENGTH_LONG).show();
                        return;
                    }
                } else if ("features".equals(name)) {
                    reader.beginArray();

                    // Обработка только первых 1000 объектов
                    int maxFeatures = 1000;
                    while (reader.hasNext() && featureCount < maxFeatures) {
                        try {
                            JsonObject feature = gson.fromJson(reader, JsonObject.class);
                            parseFeatureWithGson(feature);
                            featureCount++;

                            // Обновление прогресса
                            if (featureCount % 50 == 0) {
                                final int currentCount = featureCount;
                                runOnUiThread(() -> {
                                    Toast.makeText(this,
                                            "Обработано " + currentCount + " объектов",
                                            Toast.LENGTH_SHORT).show();
                                });
                            }
                        } catch (Exception e) {
                            Log.e("GeoJSON", "Ошибка обработки объекта", e);
                        }
                    }

                    reader.endArray();
                } else {
                    reader.skipValue();
                }
            }

            reader.endObject();
            reader.close();

            Toast.makeText(this, "Загружено " + featureCount + " объектов (лимит 1000)",
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Ошибка обработки большого файла: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }

        mapView.invalidate();
    }

    private void parseFeatureWithGson(JsonObject feature) {
        try {
            if (!feature.has("geometry")) {
                return;
            }

            JsonObject geometry = feature.getAsJsonObject("geometry");
            String geometryType = geometry.get("type").getAsString();
            JsonArray coordinates = geometry.getAsJsonArray("coordinates");

            // свойства для отображения в маркере
            String title = "Объект";
            if (feature.has("properties")) {
                JsonObject properties = feature.getAsJsonObject("properties");
                if (properties.has("name")) {
                    title = properties.get("name").getAsString();
                } else if (properties.has("nativeName")) {
                    title = properties.get("nativeName").getAsString();
                }
            }

            switch (geometryType) {
                case "Point":
                    addPointFromGson(coordinates, title);
                    break;
                case "LineString":
                    addLineStringFromGson(coordinates, title);
                    break;
                case "Polygon":
                    addPolygonFromGson(coordinates, title);
                    break;
                case "MultiPoint":
                    addMultiPointFromGson(coordinates);
                    break;
                case "MultiLineString":
                    addMultiLineStringFromGson(coordinates);
                    break;
                case "MultiPolygon":
                    addMultiPolygonFromGson(coordinates);
                    break;
                default:
                    Log.d("GeoJSON", "Неизвестный тип геометрии: " + geometryType);
            }
        } catch (Exception e) {
            Log.e("GeoJSON", "Ошибка парсинга feature", e);
        }
    }

    private void addPointFromGson(JsonArray coordinates, String title) {
        try {
            double lon = coordinates.get(0).getAsDouble();
            double lat = coordinates.get(1).getAsDouble();

            Marker marker = new Marker(mapView);
            marker.setPosition(new GeoPoint(lat, lon));
            marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            marker.setTitle(title);
            marker.setSnippet("Координаты: " + lat + ", " + lon);

            // Настраиваем внешний вид маркера
            marker.setIcon(getResources().getDrawable(android.R.drawable.ic_dialog_map));
            marker.setTextIcon(title.substring(0, Math.min(10, title.length())));

            runOnUiThread(() -> {
                mapView.getOverlays().add(marker);
                geoJsonOverlays.add(marker);
            });
        } catch (Exception e) {
            Log.e("GeoJSON", "Ошибка добавления точки", e);
        }
    }

    private void addMultiPointFromGson(JsonArray coordinates) {
        for (JsonElement pointElement : coordinates) {
            JsonArray pointCoords = pointElement.getAsJsonArray();
            addPointFromGson(pointCoords, "Точка");
        }
    }

    private void addLineStringFromGson(JsonArray coordinates, String title) {
        try {
            List<GeoPoint> geoPoints = new ArrayList<>();

            for (JsonElement pointElement : coordinates) {
                JsonArray point = pointElement.getAsJsonArray();
                double lon = point.get(0).getAsDouble();
                double lat = point.get(1).getAsDouble();
                geoPoints.add(new GeoPoint(lat, lon));
            }

            Polyline polyline = new Polyline(mapView);
            polyline.setPoints(geoPoints);
            polyline.setColor(0xFF0000FF);
            polyline.setWidth(3.0f);
            polyline.setTitle(title);

            runOnUiThread(() -> {
                mapView.getOverlays().add(polyline);
                geoJsonOverlays.add(polyline);
            });
        } catch (Exception e) {
            Log.e("GeoJSON", "Ошибка добавления линии", e);
        }
    }

    private void addMultiLineStringFromGson(JsonArray coordinates) {
        for (JsonElement lineStringElement : coordinates) {
            JsonArray lineString = lineStringElement.getAsJsonArray();
            addLineStringFromGson(lineString, "Линия");
        }
    }

    private void addPolygonFromGson(JsonArray coordinates, String title) {
        try {
            JsonArray exteriorRing = coordinates.get(0).getAsJsonArray();
            List<GeoPoint> polygonPoints = new ArrayList<>();

            for (JsonElement pointElement : exteriorRing) {
                JsonArray point = pointElement.getAsJsonArray();
                double lon = point.get(0).getAsDouble();
                double lat = point.get(1).getAsDouble();
                polygonPoints.add(new GeoPoint(lat, lon));
            }

            Polygon polygon = new Polygon(mapView);
            polygon.setPoints(polygonPoints);
            polygon.setFillColor(0x330000FF);
            polygon.setStrokeColor(0xFF0000FF);
            polygon.setStrokeWidth(2.0f);
            polygon.setTitle(title);

            runOnUiThread(() -> {
                mapView.getOverlays().add(polygon);
                geoJsonOverlays.add(polygon);
            });
        } catch (Exception e) {
            Log.e("GeoJSON", "Ошибка добавления полигона", e);
        }
    }

    private void addMultiPolygonFromGson(JsonArray coordinates) {
        for (JsonElement polygonElement : coordinates) {
            JsonArray polygon = polygonElement.getAsJsonArray();
            addPolygonFromGson(polygon, "Полигон");
        }
    }

    private void clearGeoJsonOverlays() {
        runOnUiThread(() -> {
            mapView.getOverlays().removeAll(geoJsonOverlays);
            geoJsonOverlays.clear();
            mapView.invalidate();
            Toast.makeText(this, "Карта очищена", Toast.LENGTH_SHORT).show();
        });
    }

    private String readStreamToString(InputStream inputStream) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        char[] buffer = new char[8192];
        int read;
        while ((read = reader.read(buffer)) > 0) {
            stringBuilder.append(buffer, 0, read);
        }
        reader.close();
        return stringBuilder.toString();
    }

    private void showProgress(boolean show) {
        runOnUiThread(() -> {
            progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
            btnLoadGeoJson.setEnabled(!show);
            btnClearMap.setEnabled(!show);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }
}